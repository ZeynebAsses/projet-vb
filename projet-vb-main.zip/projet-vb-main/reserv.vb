﻿Public Class reserv
    Private Sub btnReserver_Click(sender As Object, e As EventArgs) Handles btnReserver.Click
        MessageBox.Show("Réservation effectuée avec succès.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

End Class